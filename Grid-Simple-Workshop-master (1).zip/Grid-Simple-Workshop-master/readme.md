# A simple responsive website with Grid

## by Barcelona Code School

This is a 8-step workshop to build a simple responsive single page website with CSS Grid.

You can clone this repo with ```git clone https://github.com/gk3000/Grid-Simple-Workshop.git``` and follow the build process step by step. 

In every step new stuff being added and marked with comments in the html or css file. 

You can check results with these links:

[Step 1](https://gk3000.github.io/Grid-Simple-Workshop/01/index.html)

[Step 2](https://gk3000.github.io/Grid-Simple-Workshop/02/index.html)

[Step 3](https://gk3000.github.io/Grid-Simple-Workshop/03/index.html)

[Step 4](https://gk3000.github.io/Grid-Simple-Workshop/04/index.html)

[Step 5](https://gk3000.github.io/Grid-Simple-Workshop/05/index.html)

[Step 6](https://gk3000.github.io/Grid-Simple-Workshop/06/index.html)

[Step 7](https://gk3000.github.io/Grid-Simple-Workshop/07/index.html)

[Step 8](https://gk3000.github.io/Grid-Simple-Workshop/08/index.html)